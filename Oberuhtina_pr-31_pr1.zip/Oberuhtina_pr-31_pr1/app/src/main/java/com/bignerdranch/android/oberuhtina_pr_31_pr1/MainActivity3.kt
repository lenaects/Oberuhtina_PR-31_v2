package com.bignerdranch.android.oberuhtina_pr_31_pr1

import android.annotation.SuppressLint
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView

lateinit var number: TextView
lateinit var from: TextView
lateinit var to: TextView
lateinit var result: TextView
lateinit var registr:Button
class MainActivity3 : AppCompatActivity() {
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)
        number=findViewById(R.id.text5)
        from=findViewById(R.id.text6)
        to=findViewById(R.id.text7)
        result=findViewById(R.id.text8)
        registr=findViewById(R.id.but3)
        val numberValue = intent.getDoubleExtra( "number", 0.0)
        number.text = "$numberValue"
        val fromValue = intent.getStringExtra( "from")
        from.text = "Из $fromValue"
        val toValue = intent.getStringExtra( "to")
        to.text = "В $toValue"
        val resultValue = intent.getDoubleExtra( "result", 0.0)
        result.text = "Результат:$resultValue"
        registr.setOnClickListener{
            val intent = Intent(this@MainActivity3, MainActivity::class.java)
            startActivity(intent)
        }

    }
}