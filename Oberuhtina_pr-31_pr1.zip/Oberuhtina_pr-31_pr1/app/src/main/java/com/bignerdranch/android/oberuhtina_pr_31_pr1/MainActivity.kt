package com.bignerdranch.android.oberuhtina_pr_31_pr1

import android.content.Intent
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.app.FragmentTransaction
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

lateinit var pref: SharedPreferences
lateinit var login: EditText
lateinit var pass: EditText
lateinit var zar: Button
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        login = findViewById(R.id.edit1)
        pass = findViewById(R.id.edit2)
        zar=findViewById(R.id.but1)

        zar.setOnClickListener {if(login.getText().toString().trim().length>0&&pass.getText().toString().trim().length>0)
        {
            pref = getPreferences(MODE_PRIVATE)
            var save = pref.edit()
            save.putString("login",login!!.text.toString())
            save.putString("pass",pass!!.text.toString())
            save.apply()
            val intent = Intent(this@MainActivity, MainActivity2::class.java)
            startActivity(intent)
        }
        else
        {
            Toast.makeText(this,"Не заполненны данные", Toast.LENGTH_SHORT).show()
            pref = getPreferences(MODE_PRIVATE)
            val dialog=MeDialogFragment()
            val manager=supportFragmentManager
            val transaction:FragmentTransaction=manager.beginTransaction()
            dialog.show(transaction,"dialog")
        }

        }

    }
}