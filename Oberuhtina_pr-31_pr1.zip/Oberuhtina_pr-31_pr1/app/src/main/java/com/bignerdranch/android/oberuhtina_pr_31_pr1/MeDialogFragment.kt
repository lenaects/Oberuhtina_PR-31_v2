package com.bignerdranch.android.oberuhtina_pr_31_pr1

import android.app.AlertDialog
import android.app.Dialog
import android.content.SharedPreferences
import android.os.Bundle
import android.support.v4.app.DialogFragment
import android.support.v7.app.AppCompatActivity
import android.widget.Toast

class MeDialogFragment:DialogFragment() {
    override fun onCreateDialog(savedInstanceState: Bundle?):Dialog {
        return  activity?.let{
            val builder=AlertDialog.Builder(it)
            builder.setTitle("Внести прошлый пароль?")
                .setPositiveButton("OK"){_,_->

                    login!!.setText(pref.getString("login",""))
                    pass!!.setText(pref.getString("pass",""))
                    Toast.makeText(activity,"Параль записан",Toast.LENGTH_LONG).show()
                }
                .setNegativeButton("NO"){_,_->

                    Toast.makeText(activity,"Пароль не записан",Toast.LENGTH_SHORT).show()
                }
            builder.create()
        }?: throw IllegalStateException("Activity cannot be null")
    }
}