package com.bignerdranch.android.oberuhtina_pr_31_pr1

import android.annotation.SuppressLint
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

lateinit var spin1:Spinner
lateinit var spin2:Spinner
lateinit var but: Button
lateinit var value:EditText
lateinit var rez:TextView

class MainActivity2 : AppCompatActivity() {
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        spin1 = findViewById(R.id.spin1)
        spin2 = findViewById(R.id.spin2)
        but=findViewById(R.id.but2)
        value=findViewById(R.id.edit3)
        rez=findViewById(R.id.text1)
        val units = arrayOf("Байт", "Килобайт", "Мегабайт", "Гигабайт")
        val adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_item,units).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        spin1.adapter = adapter
        spin1.setSelection(0)
        spin2.adapter = adapter
        spin2.setSelection(0)

        but.setOnClickListener{
            if(value.text.isNotEmpty()) {
                val inputValue = value.text.toString().toDouble()
                val inputUnit = spin1.selectedItemPosition
                val outputUnit = spin2.selectedItemPosition

                val outputValue = convert(inputValue, inputUnit, outputUnit)
                rez.text = "$outputValue ${units[outputUnit]}"

                val intent = Intent(this@MainActivity2,MainActivity3::class.java)
                intent.putExtra("number", inputValue)
                intent.putExtra("from", spin1.getSelectedItem().toString())
                intent.putExtra("to",  spin2.getSelectedItem().toString())
                intent.putExtra("result", outputValue)
                startActivity(intent)
            }
            else {
                Toast.makeText(this, "Введи число", Toast.LENGTH_SHORT).show()
                rez.text = "Результат"
            }
        }

    }
    private fun convert(value: Double, inputUnit: Int, outputUnit: Int): Double {
        val baseUnits = arrayOf(1, 1024, 1024 * 1024, 1024 * 1024 * 1024)
        val inputValueInBytes = value * baseUnits[inputUnit]
        val outputValue = inputValueInBytes / baseUnits[outputUnit]
        return outputValue
    }
}